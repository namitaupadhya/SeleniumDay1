package com.tests;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void test1() {
	  System.out.println("test1");
  }
}
